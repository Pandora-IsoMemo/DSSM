testing upload of a model
