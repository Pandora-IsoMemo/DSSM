test upload of a model
