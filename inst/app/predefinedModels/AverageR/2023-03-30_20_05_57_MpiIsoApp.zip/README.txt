test upload of model
