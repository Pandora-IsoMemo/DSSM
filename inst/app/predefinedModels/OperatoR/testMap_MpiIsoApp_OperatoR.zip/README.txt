testing upload of maps
